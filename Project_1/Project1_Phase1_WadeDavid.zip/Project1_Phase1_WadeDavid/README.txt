The writeup and prject pictures are located in the Submission_files folder. 
In addition, there is a video and picture showing the proof of operation. 
All other project files are located in this main directory. 